package com.example.resgateurbano

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
