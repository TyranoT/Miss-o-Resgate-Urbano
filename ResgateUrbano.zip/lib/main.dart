import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DetalhesChamadoScreen(),
    ),
  );
}

class DetalhesChamadoScreen extends StatefulWidget {
  @override
  State<DetalhesChamadoScreen> createState() => _DetalhesChamadoScreenState();
}

class _DetalhesChamadoScreenState extends State<DetalhesChamadoScreen> {
  TextEditingController tituloController = TextEditingController(
    text: "Semáforo quebrado",
  );

  TextEditingController descricaoController = TextEditingController(
    text: "Semáforo da avenida principal apagado",
  );

  TextEditingController bairroController = TextEditingController(
    text: "Centro",
  );

  TextEditingController responsavelController = TextEditingController(
    text: "Equipe Urbana",
  );

  String categoria = "trânsito";
  String prioridade = "alta";
  String status = "aberto";

  bool editando = false;

  List<String> categorias = [
    "trânsito",
    "iluminação",
    "saneamento",
    "segurança",
    "limpeza urbana",
    "desastre natural"
  ];

  List<String> prioridades = ["baixa", "média", "alta", "crítica"];

  List<String> statusList = ["aberto", "em andamento", "concluído"];

  @override
  Widget build(BuildContext context) {
    bool bloqueado = status == "concluído";

    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: Text("Detalhes do Chamado"),
        centerTitle: true,
        actions: [
          if (!bloqueado)
            IconButton(
              icon: Icon(
                editando ? Icons.close : Icons.edit,
              ),
              onPressed: () {
                setState(() {
                  editando = !editando;
                });
              },
            ),
        ],
      ),
      floatingActionButton: editando
          ? FloatingActionButton.extended(
              onPressed: salvarEdicao,
              icon: Icon(Icons.save),
              label: Text("Salvar"),
            )
          : null,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (bloqueado)
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.green[100],
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    Icon(Icons.lock),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "Chamado concluído não pode ser editado.",
                      ),
                    ),
                  ],
                ),
              ),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: corPrioridade(prioridade),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Text(
                prioridade.toUpperCase(),
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 25),
            campoTexto(
              controller: tituloController,
              label: "Título",
              icone: Icons.title,
            ),
            SizedBox(height: 16),
            campoTexto(
              controller: descricaoController,
              label: "Descrição",
              icone: Icons.description,
              linhas: 4,
            ),
            SizedBox(height: 16),
            dropdownCampo(
              valor: categoria,
              lista: categorias,
              label: "Categoria",
              icone: Icons.category,
              onChanged: (value) {
                setState(() {
                  categoria = value!;
                });
              },
            ),
            SizedBox(height: 16),
            dropdownCampo(
              valor: prioridade,
              lista: prioridades,
              label: "Prioridade",
              icone: Icons.priority_high,
              onChanged: (value) {
                setState(() {
                  prioridade = value!;
                });
              },
            ),
            SizedBox(height: 16),
            campoTexto(
              controller: bairroController,
              label: "Bairro",
              icone: Icons.location_city,
            ),
            SizedBox(height: 16),
            campoTexto(
              controller: responsavelController,
              label: "Responsável",
              icone: Icons.person,
            ),
            SizedBox(height: 16),
            dropdownCampo(
              valor: status,
              lista: statusList,
              label: "Status",
              icone: Icons.info,
              onChanged: (value) {
                setState(() {
                  status = value!;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget campoTexto({
    required TextEditingController controller,
    required String label,
    required IconData icone,
    int linhas = 1,
  }) {
    return TextField(
      controller: controller,
      enabled: editando,
      maxLines: linhas,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        labelText: label,
        prefixIcon: Icon(icone),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget dropdownCampo({
    required String valor,
    required List<String> lista,
    required String label,
    required IconData icone,
    required Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: valor,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        labelText: label,
        prefixIcon: Icon(icone),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
      items: lista.map((item) {
        return DropdownMenuItem<String>(
          value: item,
          child: Text(item),
        );
      }).toList(),
      onChanged: editando ? onChanged : null,
    );
  }

  Color corPrioridade(String prioridade) {
    switch (prioridade) {
      case "baixa":
        return Colors.green;

      case "média":
        return Colors.orange;

      case "alta":
        return Colors.deepOrange;

      case "crítica":
        return Colors.red;

      default:
        return Colors.blue;
    }
  }

  void salvarEdicao() {
    if (tituloController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Título obrigatório"),
        ),
      );

      return;
    }

    if (descricaoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Descrição obrigatória"),
        ),
      );

      return;
    }

    setState(() {
      editando = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Chamado atualizado!"),
      ),
    );
  }
}
